#copy this file to /etc/profile.d/
export JAVA_HOME=/usr/jdk64/jdk1.8.0_112
export PATH=$PATH:$JAVA_HOME/bin