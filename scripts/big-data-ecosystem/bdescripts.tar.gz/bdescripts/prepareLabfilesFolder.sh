cd /
wget https://github.com/IBM-SkillsAcademy/big-data-eng-2020/raw/master/big-data-ecosystem/labfiles.tar.gz
tar -xzvf labfiles.tar.gz
