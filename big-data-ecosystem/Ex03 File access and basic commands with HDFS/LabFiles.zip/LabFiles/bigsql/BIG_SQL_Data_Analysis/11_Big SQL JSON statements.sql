CREATE HADOOP TABLE IF NOT EXISTS weather_parquet (
id varchar(30),
location_id varchar(20),
narrative varchar(1000),
min_temp int,
max_temp int,
validitydate varchar(50) )
STORED AS parquetfile
as
select hive.get_json_object(json,'$.metadata.transaction_id') as id, 
hive.get_json_object(json,'$.metadata.location_id') as	location_id,
hive.get_json_object(json,'$.forecasts[0].narrative') as nextforecast,
cast(hive.get_json_object(json, '$.forecasts[0].min_temp') as integer) as min_temp,
cast(hive.get_json_object(json, '$.forecasts[0].max_temp') as integer) as max_temp,
hive.get_json_object(json,'$.forecasts[0].fcst_valid_local') as validitydate
from weather;