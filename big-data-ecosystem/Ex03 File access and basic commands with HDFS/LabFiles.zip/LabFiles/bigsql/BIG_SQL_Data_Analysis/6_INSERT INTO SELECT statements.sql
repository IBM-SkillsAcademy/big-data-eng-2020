-- create a sample sales_report table
CREATE HADOOP TABLE sales_report 
( 
product_key       INT NOT NULL, 
product_name	VARCHAR(150), 
quantity 		INT, 
order_method_en	VARCHAR(90)
)
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
LINES TERMINATED BY '\n'
STORED AS TEXTFILE;

-- populate the sales_report data with results from a query 
INSERT INTO sales_report 
SELECT sales.product_key, pnumb.product_name, sales.quantity,
meth.order_method_en
FROM
sls_sales_fact sales,
sls_product_dim prod,
sls_product_lookup pnumb,
sls_order_method_dim meth
WHERE
pnumb.product_language='EN'
AND sales.product_key=prod.product_key
AND prod.product_number=pnumb.product_number
AND meth.order_method_key=sales.order_method_key  
and sales.quantity > 1000;

-- total number of rows should be 14441 
select count(*) from sales_report;


