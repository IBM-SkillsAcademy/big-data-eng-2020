create view myview as 
select product_name, sales.product_key, mkt.quantity, 
sales.order_day_key, sales.sales_order_key, order_method_en
from
mrk_promotion_fact mkt, 
	sls_sales_fact sales, 
	sls_product_dim prod, 
	sls_product_lookup pnumb, 
	sls_order_method_dim meth
where mkt.order_day_key=sales.order_day_key 
	and sales.product_key=prod.product_key 
	and prod.product_number=pnumb.product_number 
	and pnumb.product_language='EN' 
	and meth.order_method_key=sales.order_method_key; 

//
select * from myview 	
order by product_key asc, order_day_key asc
fetch first 20 rows only;

