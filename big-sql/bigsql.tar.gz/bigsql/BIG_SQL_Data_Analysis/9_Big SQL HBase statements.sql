CREATE HBASE TABLE IF NOT EXISTS REVIEWS ( 
REVIEWID 		varchar(10) primary key not null,
PRODUCT			varchar(30), 
RATING			int, 
REVIEWERNAME	varchar(30), 
REVIEWERLOC		varchar(30), 
COMMENT			varchar(100), 
TIP				varchar(100)
) 
COLUMN MAPPING 
( 
key					mapped by (REVIEWID), 
summary:product		mapped by (PRODUCT),
summary:rating  		mapped by (RATING),
reviewer:name		mapped by (REVIEWERNAME),
reviewer:location  	mapped by (REVIEWERLOC),
details:comment    	mapped by (COMMENT),
details:tip	   		mapped by (TIP) 
);



-- product dimension table
CREATE HBASE TABLE IF NOT EXISTS sls_product_dim
 ( product_key INT PRIMARY KEY NOT NULL
 , product_line_code INT NOT NULL
 , product_type_key INT NOT NULL
 , product_type_code INT NOT NULL
 , product_number INT NOT NULL
 , base_product_key INT NOT NULL
 , base_product_number INT NOT NULL
 , product_color_code INT
 , product_size_code INT
 , product_brand_key INT NOT NULL
 , product_brand_code INT NOT NULL
 , product_image VARCHAR(60)
 , introduction_date TIMESTAMP
 , discontinued_date TIMESTAMP
 )
COLUMN MAPPING 
( 
key					mapped by (PRODUCT_KEY),  
data:line_code		mapped by (PRODUCT_LINE_CODE), 
data:type_key		mapped by (PRODUCT_TYPE_KEY), 
data:type_code		mapped by (PRODUCT_TYPE_CODE),
data:number			mapped by (PRODUCT_NUMBER),
data:base_key		mapped by (BASE_PRODUCT_KEY),
data:base_number		mapped by (BASE_PRODUCT_NUMBER),
data:color			mapped by (PRODUCT_COLOR_CODE),
data:size			mapped by (PRODUCT_SIZE_CODE),
data:brand_key		mapped by (PRODUCT_BRAND_KEY),
data:brand_code		mapped by (PRODUCT_BRAND_CODE),
data:image			mapped by (PRODUCT_IMAGE),
data:intro_date		mapped by (INTRODUCTION_DATE),
data:discon_date		mapped by (DISCONTINUED_DATE) 
	);
