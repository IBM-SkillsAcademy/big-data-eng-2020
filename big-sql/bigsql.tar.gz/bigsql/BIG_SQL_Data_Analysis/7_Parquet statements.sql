CREATE HADOOP TABLE IF NOT EXISTS big_sales_parquet 
( product_key     INT NOT NULL, 
product_name	VARCHAR(150), 
quantity 		INT, 
order_method_en    VARCHAR(90)
)
STORED AS parquetfile;

insert into big_sales_parquet 
SELECT sales.product_key, pnumb.product_name, sales.quantity,
meth.order_method_en
FROM
sls_sales_fact sales,
sls_product_dim prod,
sls_product_lookup pnumb,
sls_order_method_dim meth
WHERE
pnumb.product_language='EN'
AND sales.product_key=prod.product_key
AND prod.product_number=pnumb.product_number
AND meth.order_method_key=sales.order_method_key  
and sales.quantity > 5500;

select * from big_sales_parquet;

