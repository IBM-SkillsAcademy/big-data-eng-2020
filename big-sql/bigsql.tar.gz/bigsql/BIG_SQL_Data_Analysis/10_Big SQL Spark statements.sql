CREATE hbase TABLE IF NOT EXISTS sls_product_flat
( product_key INT NOT NULL
	, product_line_code INT NOT NULL
	, product_type_key INT NOT NULL
	, product_type_code INT NOT NULL
	, product_line_en VARCHAR(90)
	, product_line_de VARCHAR(90)
)
column mapping
(
	key mapped by (product_key),
	data:c2 mapped by (product_line_code),
	data:c3 mapped by (product_type_key),
	data:c4 mapped by (product_type_code),
	data:c5 mapped by (product_line_en),
	data:c6 mapped by (product_line_de)
)
as select product_key, d.product_line_code, product_type_key, product_type_code, product_line_en, product_line_de
from 
sls_product_dim_external d, sls_product_line_lookup l
where d.product_line_code = l.product_line_code;